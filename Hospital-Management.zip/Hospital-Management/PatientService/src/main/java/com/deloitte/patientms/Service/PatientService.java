package com.deloitte.patientms.Service;

import java.util.List;

import com.deloitte.patientms.entity.Patient;

public interface PatientService {
	
	public List <Patient> getPatients();
	public List<Patient> getPatient(Integer id);
	
}
