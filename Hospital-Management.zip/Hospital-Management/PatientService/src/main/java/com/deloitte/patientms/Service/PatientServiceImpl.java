package com.deloitte.patientms.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.patientms.Repository.PatientRepository;
import com.deloitte.patientms.entity.Patient;

@Service
public class PatientServiceImpl implements PatientService {

	@Autowired
	PatientRepository patientRepository;

	@Override
	public List<Patient> getPatients() {
		// TODO Auto-generated method stub
		return patientRepository.findAll();
	}

	@Override
	public List<Patient> getPatient(Integer id) {
		// TODO Auto-generated method stub
		return patientRepository.findByPid(id);
	}

}
