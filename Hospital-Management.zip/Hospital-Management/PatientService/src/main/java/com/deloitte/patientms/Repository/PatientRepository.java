package com.deloitte.patientms.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.deloitte.patientms.entity.Patient;

@Repository
public interface PatientRepository  extends JpaRepository<Patient,Integer>{
	
	public List<Patient> findByPid(Integer pid);
	

}
