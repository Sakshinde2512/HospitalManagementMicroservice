package com.deloitte.patientms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deloitte.patientms.Service.PatientService;
import com.deloitte.patientms.Service.PatientServiceImpl;
import com.deloitte.patientms.entity.Patient;

@RestController
@RequestMapping("/Mypatients")
public class PatientController {

	@Autowired
	PatientService patientService;
	

	@GetMapping("/getpatients")
	public ResponseEntity<List<Patient>> getAllPatients() {
		List<Patient> patients = patientService.getPatients();

		return new ResponseEntity<List<Patient>>(patients, HttpStatus.OK);

	}

	@GetMapping("/getPatient/{pid}")
	public ResponseEntity<List<Patient>> getPatientByPid(@PathVariable("pid") Integer pid) {
		List<Patient> patient = patientService.getPatient(pid);
		return new ResponseEntity<List<Patient>>(patient, HttpStatus.OK);

	}
}
