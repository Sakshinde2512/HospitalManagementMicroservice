package com.deloitte.doctorms.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.deloitte.doctorms.entity.Doctor;

public interface DoctorService {

	public List <Doctor> getDoctors();
	public Doctor getDoctor(Integer id);
}
