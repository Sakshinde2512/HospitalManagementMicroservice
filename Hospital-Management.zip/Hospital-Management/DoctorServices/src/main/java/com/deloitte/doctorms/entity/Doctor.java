package com.deloitte.doctorms.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Doctor {

	
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="did")
	private Integer did;
	@Column(name="dname")
	private String dname;
	@Column(name="department")
	private String department;
	@Column(name="pid")
	private Integer  pid;
	@Column(name="salary")
	private double salary;
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getDid() {
		return did;
	}
	public void setDid(Integer did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Doctor(Integer did, String dname, String department, Integer pid, double salary) {
		super();
		this.did = did;
		this.dname = dname;
		this.department = department;
		this.pid = pid;
		this.salary = salary;
	}

}
