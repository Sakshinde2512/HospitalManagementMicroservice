package com.deloitte.doctorms.model;

public class Patient {

	// @GeneratedValue(strategy = GenerationType.AUTO)

	private Integer pid;

	private String pname;

	private String paddress;

	private String pgender;

	private String disease;

	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPaddress() {
		return paddress;
	}

	public void setPaddress(String paddress) {
		this.paddress = paddress;
	}

	public String getPgender() {
		return pgender;
	}

	public void setPgender(String pgender) {
		this.pgender = pgender;
	}

	public String getDisease() {
		return disease;
	}

	public void setDisease(String disease) {
		this.disease = disease;
	}

	public Patient(Integer pid, String pname, String paddress, String pgender, String disease) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.paddress = paddress;
		this.pgender = pgender;
		this.disease = disease;
	}

}
