package com.deloitte.doctorms.model;


import java.util.List;

import com.deloitte.doctorms.entity.Doctor;
import com.deloitte.patientms.entity.Patient;

import jakarta.ws.rs.core.EntityTag;
import jakarta.ws.rs.core.GenericType;
import jakarta.ws.rs.core.Link;
import jakarta.ws.rs.core.Link.Builder;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.MultivaluedMap;
import jakarta.ws.rs.core.NewCookie;

public class Response {

	Doctor doctor;
	List<Patient> patientList;
	
	public Response() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Response(Doctor doctor, List<Patient> patientList) {
		super();
		this.doctor = doctor;
		this.patientList = patientList;
	}
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	public List<Patient> getPatientList() {
		return patientList;
	}
	public void setPatientList(List<Patient> patientList) {
		this.patientList = patientList;
	}
	
}
