package com.deloitte.doctorms.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.doctorms.Repository.DoctorRepository;
import com.deloitte.doctorms.entity.Doctor;
import com.deloitte.patientms.Repository.PatientRepository;
import com.deloitte.patientms.Service.PatientService;
import com.deloitte.patientms.entity.Patient;
@Service
public class DoctorServiceImpl implements  DoctorService{
	
	@Autowired
	DoctorRepository doctorRepository;

	@Override
	public List<Doctor> getDoctors() {
		// TODO Auto-generated method stub
		return doctorRepository.findAll();
	}

	@Override
	public Doctor getDoctor(Integer id) {
		// TODO Auto-generated method stub
		return doctorRepository.findByPid(id);
	}

}
