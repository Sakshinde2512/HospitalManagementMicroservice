package com.deloitte.doctorms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.deloitte.doctorms.Service.DoctorService;
import com.deloitte.doctorms.entity.Doctor;
import com.deloitte.doctorms.model.Response;
import com.deloitte.patientms.Service.PatientService;
import com.deloitte.patientms.entity.Patient;

import jakarta.ws.rs.core.Response;

@RestController
@RequestMapping("/Mydoctors")
public class DoctorController {

	@Autowired
	DoctorService doctorService;

	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/getdoctors")
	public ResponseEntity<List<Doctor>> getAllDoctors() {
		List<Doctor> doctor = doctorService.getDoctors();
		return new ResponseEntity<List<Doctor>>(doctor, HttpStatus.OK);
	}

	@GetMapping("/getdoctor/{pid}")
	public ResponseEntity<Response> getdoctorByPid(@PathVariable("pid") Integer pid) {

		Doctor doctor = doctorService.getDoctor(pid);
		List<Patient> patientList = restTemplate.getForObject("http://localhost:8087/Mypatients/getPatient/" + pid, List.class);
		Response response = new Response(doctor, patientList);
		return new ResponseEntity<Response>(response, HttpStatus.OK);

	}
}
